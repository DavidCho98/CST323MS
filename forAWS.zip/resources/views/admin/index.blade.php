<x-admin-master>

    @section('content')

        <h1 class="h3 mb-4 text-gray-800">Profile</h1>

    @endsection


</x-admin-master>
